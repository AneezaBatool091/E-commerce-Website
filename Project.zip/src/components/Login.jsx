import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Col, Container, Row } from "react-bootstrap";
function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle login logic here
        navigate('/profile');
    };

    return (
        <Container className='signup-container'>
            <Row>
            <Col md={12}>
        <div className='login'>
            <h2 className='s1'>Login</h2>
            
            <form onSubmit={handleSubmit}>
                <div className='form'>
                    <div>
                    <label>Email: </label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                  </div>
                  <p></p>
                 <div>
                    <label>Password:</label>
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                 </div>
                 <button className='submit' type="submit">Login</button>
                  </div>
                      </form>
       
                      </div>
                </Col >
               </Row>
              </Container>
    );
}

export default Login;
