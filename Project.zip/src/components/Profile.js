// src/components/Profile.js
import React from 'react';

function Profile() {
    // Fetch user profile data here if needed
    return (
        <div>
            <h2>Profile</h2>
            <p>Welcome, [User Name]!</p>
        </div>
    );
}

export default Profile;
