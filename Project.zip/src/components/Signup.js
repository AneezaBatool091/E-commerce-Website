// src/components/Signup.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Col, Container, Row } from "react-bootstrap";
function Signup() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle signup logic here
        navigate('/profile');
    };

    return (
        <Container className='signup-container'>
        <Row>
        <Col md={12}>
        <div className='signup'>
            <h2 className='s1'>Signup</h2><p></p>
            
            
            <form onSubmit={handleSubmit}>
                <div className='form'>
                    <div>
                    <label>Name:</label>
                    <input className='name' type="text" value={name} onChange={(e) => setName(e.target.value)} required /><p></p>
                </div>
                <div>
                    <label>Email: </label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /><p></p>
                </div>
                <div>
                    <label>Password:  </label>
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /><p></p>
                </div>
                <button className='submit' type="submit">Signup</button>
                </div>
            </form>
        </div>
        </Col>
        </Row>
        </Container>
    );
}

export default Signup;