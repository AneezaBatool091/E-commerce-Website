// src/components/Checkout.js
import React, { useState } from 'react';
import { Col, Container, Row } from "react-bootstrap";
function Checkout() {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    const [instructions, setInstructions] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle order placement logic here
        alert('Order placed successfully!');
    };

    return (
        <Container className='signup-container'>
        <Row>
        <Col md={12}>
        
        <div className='check-out'>
            <h2 className='s1'>Checkout</h2>
            <form onSubmit={handleSubmit}>
                <div className='form'>
                    <div>
                    <label>Name:</label>
                    <input className='name' type="text" value={name} onChange={(e) => setName(e.target.value)} required />
                 </div>
                 <div>
                    <label  >Phone:</label>
                    <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                 </div>
                 <div>
                    <label>Email:</label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                 </div>
                 <div className='ad-in'> 
                    <label>Address:</label>
                    <textarea value={address} onChange={(e) => setAddress(e.target.value)} required />
                </div>
                <div className='ad-in'>
                    <label>Instructions:</label>
                    <textarea  value={instructions} onChange={(e) => setInstructions(e.target.value)} />
                </div>
                <button className='submit' type="submit">Place Order</button>
                </div>
            </form>
        </div>
        </Col>
        </Row>
        </Container>
    );
}

export default Checkout;
